#include <Arduino.h>
#include <SPI.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <stdio.h>
#include <Filters.h>
#include <AH/Timing/MillisMicrosTimer.hpp>
#include <Filters/Notch.hpp>
#include <vector>
#include <Filters/MedianFilter.hpp> 
#include <Filters/Butterworth.hpp>
#include <AH/Timing/MillisMicrosTimer.hpp>


// --- Constantes ---

const unsigned long Fmod = 128000;           // Frecuencia de modulación (Hz)
const unsigned long Fclk = 2048000000UL;     // Frecuencia de reloj (Hz)
const float Tclk = 1.0f / Fmod;              // Periodo del reloj (s)
const float Vref = 4.033f;                   // Voltaje de referencia (V)
const float Pga = 12.0f;                     // Ganancia del amplificador
const float Resistencia_shunt = 0.5f;        // Resistencia shunt (Ohm)
const float Threshold_corriente = 0.9f;      // Umbral de corriente para detección
bool data_preparada = false; // Variable para indicar si los datos están listos

// --- VARIABLES FILTRO FRECUENCIA ---
 // Sampling frequency
const double f_s = 500; // Hz
 // Notch frequency (-∞ dB)
const double f_c = 60; // Hz
 // Normalized notch frequency
const double f_n = 2 * f_c / f_s;
auto filter1 = simpleNotchFIR(f_n); // fundamental
auto filter2 = simpleNotchFIR(2 * f_n); // second harmonic
// Cut-off frequency (-3 dB)
const double f_c_pb = 250; // Hz
// Normalized cut-off frequency
const double f_n_pb= 2 * f_c_pb / f_s;
// Sample timer
Timer<micros> timer = std::round(1e6 / f_s);
// Sixth-order Butterworth filter
auto filter = butter<6>(f_n);

// --- VARIABLES DETECCIÓN DE LA CONTRACCIÓN --- 
#define SAMPLE_SIZE 30
#define PEAK_WINDOW 5
int32_t emgBuffer[PEAK_WINDOW]; // Para detectar picos locales
int32_t peakValues[SAMPLE_SIZE];
int peakCount = 0;
bool calibrationDone = false;
int32_t peakMedian = 0;
int32_t peakStdDev = 0;
int32_t threshold = 0;
int32_t lastPeakValue = 0;
int consecutivePeakCount = 0;
unsigned long calibrationStartTime = 0;
bool calibrationStarted = false;
int bufferFillCount = 0;
int lowPeakCount = 0;  // Contador de picos por debajo del umbral
std::vector<float> calibrationSamples;
bool muscleOn = false;

int32_t emgData = 0;
unsigned long lastPeakTime = 0;  // Tiempo del último pico válido
long servoData = 0;
bool configuracion=false;
#define PEAK_SAMPLE_SIZE 200
int32_t initialPeaks[PEAK_SAMPLE_SIZE];
uint8_t initialPeakCount = 0;
bool peakRangeComputed = false;
int32_t PEAK_MIN_HEIGHT = 0;
int32_t PEAK_MAX_HEIGHT = 0;

// --- Comandos del ADS1292 ---

#define CMD_WAKEUP   0x02
#define CMD_STANDBY  0x04
#define CMD_RESET    0x06
#define CMD_START    0x08
#define CMD_STOP     0x0A
#define CMD_RDATAC   0x10
#define CMD_SDATAC   0x11
#define CMD_RDATA    0x12

// --- PINES SPI ---

#define ADS1292_MISO 33
#define ADS1292_MOSI 26
#define ADS1292_CS_PIN 27  
#define ADS1292_SCK 25
#define ADS1292_DRDY_PIN 32
#define ADS1292_START_PIN 14
#define ADS1292_PWDN_PIN 13

// --- REGISTROS DEL ADS1292 ---

#define CONFIG1      0x01
#define CONFIG2      0x02
#define LOFF         0x03
#define CH1SET       0x04
#define CH2SET       0x05
#define RLD_SENS     0x06
#define LOFF_SENSE   0x07
#define LOFF_STAT    0x08
#define RESP1        0x09
#define RESP2        0x0A

 
// --- VARIABLES DEL ADS1292 ---
#define TIMEOUT_MS 1000  // 1 segundo

#define DATA_LENGTH 9    // 3 status + 2 canales * 3 bytes

#define RDATA_LENGTH 9

#define CONFIG_SPI_MASTER_DUMMY 0xFF  // Byte de relleno para SPI

extern float decode_data(uint8_t *data, float vref, float pga);

 
// --- FUNCIONES---

void ads1292_writeCommand(uint8_t cmd) {
//Función para enviar un comando al ADS1292
  digitalWrite(ADS1292_CS_PIN, LOW);
  delayMicroseconds(2);
  SPI.transfer(cmd);
  delayMicroseconds(2);
  digitalWrite(ADS1292_CS_PIN, HIGH);
  delay(1);
}

uint8_t read_register(uint8_t register_address) {
  // Función para leer un registro del ADS1292
  digitalWrite(ADS1292_CS_PIN, LOW);
  delayMicroseconds(2);
  // Enviar comando para leer registro + dirección y número de registros (1 registro, n-1=0)
  SPI.transfer(0x20 | register_address);
  SPI.transfer(0x00);
  // Leer un byte dummy para recibir el dato
  uint8_t data = SPI.transfer(0x00);
  digitalWrite(ADS1292_CS_PIN, HIGH);
  return data;
}

void write_register(uint8_t register_address, uint8_t value) {
  // Función para escribir un valor en un registro del ADS1292
  digitalWrite(ADS1292_CS_PIN, LOW);
  delayMicroseconds(2);  // Estabilización
  // Enviar comando de escritura al registro
  SPI.transfer(0x40 | register_address);  // 0x40 = Write Register Command
  SPI.transfer(0x00);                     // Número de registros a escribir - 1 (solo 1)
  SPI.transfer(value);                    // Valor del registro
  delayMicroseconds(2);  // Recomendado por el datasheet
  digitalWrite(ADS1292_CS_PIN, HIGH);
  delay(1);  // Mínimo delay tras escritura
}

void reinicialitza_ads1292r() {
  // Función para reinicializar el ADS1292
  digitalWrite(ADS1292_PWDN_PIN, LOW);
  delay(2);
  digitalWrite(ADS1292_PWDN_PIN, HIGH);
  delay(100);
  ads1292_writeCommand(CMD_RESET);
  delay(10);
  ads1292_writeCommand(CMD_SDATAC);
  delay(10);
  digitalWrite(ADS1292_START_PIN, HIGH);
}

void start_conversion() {
  // Función para iniciar la conversión del ADS1292
    ads1292_writeCommand(CMD_START);
}
void enable_continuous_reading() {
    // Función para habilitar la lectura continua de datos
    ads1292_writeCommand(CMD_RDATAC);
    start_conversion();
}
void disable_continuous_reading() {
    // Función para deshabilitar la lectura continua de datos
    ads1292_writeCommand(CMD_SDATAC);
}

 void stop_conversion() {
    // Función para detener la conversión del ADS1292
    ads1292_writeCommand(CMD_STOP);
}

void IRAM_ATTR wait_data_DRDY() {
// Función de interrupción para esperar el pin DRDY
    data_preparada=true;
}

void read_data(uint8_t *out_data) {
    // Función para leer datos del ADS1292
    digitalWrite(ADS1292_CS_PIN, LOW);
    SPI.transfer(CMD_RDATA);
    for (int i = 0; i < RDATA_LENGTH; i++) {

        out_data[i] = SPI.transfer(0x00);
    }
    digitalWrite(ADS1292_CS_PIN, HIGH);
}

void readADS1292Samples() {
    // Función para leer muestras del ADS1292
    uint8_t spiBuffer[9];
    digitalWrite(ADS1292_CS_PIN, LOW);
    for (int i = 0; i < 9; i++) {
      spiBuffer[i] = SPI.transfer(CONFIG_SPI_MASTER_DUMMY);
      //Serial.print(spiBuffer[i]);
      //Serial.print(", ");
    }
    //Serial.println(" ");
    digitalWrite(ADS1292_CS_PIN, HIGH);
    // Procesamiento de los datos leídos
    emgData = ((uint32_t)spiBuffer[3] << 16) |

              ((uint32_t)spiBuffer[4] << 8) |

              (uint32_t)spiBuffer[5];

    if (emgData & 0x800000) emgData |= 0xFF000000;
    servoData = ((long)spiBuffer[6] << 16) |

                ((long)spiBuffer[7] << 8) |

                (long)spiBuffer[8];

    if (servoData & 0x800000) servoData |= 0xFF000000;
}

void ads1292_init() {
  // Configurar pines
  pinMode(ADS1292_PWDN_PIN, OUTPUT);
  pinMode(ADS1292_CS_PIN, OUTPUT);
  pinMode(ADS1292_START_PIN, OUTPUT);
  pinMode(ADS1292_DRDY_PIN, INPUT);
  pinMode(ADS1292_SCK, OUTPUT);
  pinMode(ADS1292_MISO, INPUT);
  pinMode(ADS1292_MOSI, OUTPUT);
  // Configurar pines SPI
  Serial.begin(115200); 
  delay(1);
  SPI.end(); 
  // Iniciar la comunicación SPI
  Serial.println("Iniciando SPI...");
  SPI.begin(ADS1292_SCK, ADS1292_MISO, ADS1292_MOSI, ADS1292_CS_PIN);
  // Configura el bus SPI
  SPI.beginTransaction(SPISettings(600000, MSBFIRST, SPI_MODE1)); // CPOL=0, CPHA=1
}

void emg_configuration() {
  // Configuración del ADS1292
  Serial.println("Configurando ADS1292...");
  digitalWrite(ADS1292_PWDN_PIN, HIGH);
  delay(100);         // Wait 100 mSec
  digitalWrite(ADS1292_PWDN_PIN, LOW);
  delay(100);
  digitalWrite(ADS1292_PWDN_PIN, HIGH);
  delay(200);
  digitalWrite(ADS1292_START_PIN, LOW);
  delay(20);
  //digitalWrite(ADS1292_START_PIN, HIGH);

  //delay(20);

  //digitalWrite(ADS1292_START_PIN, LOW);

  //delay(100);

  disable_continuous_reading();

  //UTILIZO REGISTROS EMG

  // 0x04 per 2ksps.  0xB0 per 500sps

  write_register(CONFIG1, 0x02); // Configuración del registro CONFIG1
  delay(10);
  write_register(CONFIG2, 0xA0); //CANVIAT
  delay(10);
  //write_register(CONFIG1, 0x02);
  write_register(CH1SET, 0x60);
  delay(10);
  write_register(CH2SET, 0x81);
  delay(10);
  write_register(RLD_SENS, 0xE3); //fmod /4
  delay(10);
  write_register(RESP1, 0x02); // Configuración de detección de desconexión
  delay(10);
  write_register(RESP2, 0x07);
}

bool comprobar_connexion_SPI() {
    // Función para comprobar la conexión SPI del ADS1292
    uint8_t id_val = 0;
    int intents = 0;
    while (intents < 3) {
        id_val = read_register(0x00);
        Serial.print("Intent ");
        Serial.print(intents + 1);
        Serial.print(": Registre ID (0x00)= 0x");
        if (id_val < 0x10) Serial.print("0");
        Serial.println(id_val, HEX);
        if (id_val == 0x53) {
            break;
        }
        intents++;
        reinicialitza_ads1292r();
        delay(100);  // 0.1 segundos
    }
    if (id_val != 0x53) {
        Serial.println("⚠️ Error: No s'ha detectat ID vàlid després de 3 intents.");
        return false;
    } else {
        Serial.println("✅ ID vàlid detectat.");
        return true;
    }
}

void leer_registros_config() {
  // Función para leer los registros de configuración del ADS1292
  uint8_t ch1 = read_register(CH1SET);
  uint8_t ch2 = read_register(CH2SET);
  uint8_t rld = read_register(RLD_SENS);
  uint8_t resp = read_register(RESP2);
  Serial.print("CH1SET: 0x");
  Serial.println(ch1, HEX);
  Serial.print("CH2SET: 0x");
  Serial.println(ch2, HEX);
  Serial.print("RLD_SENS: 0x");
  Serial.println(rld, HEX);
  Serial.print("RESP2: 0x");
  Serial.println(resp, HEX);
  Serial.println("--------------------");
  if(ch1!= 0x60|| ch2 != 0x81 || rld != 0xE3 || resp != 0x07) {
    Serial.println("⚠️ Configuración incorrecta. Reconfigurando...");
    configuracion= false;

  } else {
    configuracion = true;
    Serial.println("✅ Configuración correcta.");
  }
}

bool isCalibrationPeak(int32_t currentValue) {
  // Verifica si el valor actual es un pico de calibración
  bool isLocalPeak = emgBuffer[1] >emgBuffer[0] && emgBuffer[1] >emgBuffer[2];
  bool heightInRange = (emgBuffer[1] >= PEAK_MIN_HEIGHT) && (emgBuffer[1] <= PEAK_MAX_HEIGHT);
  return isLocalPeak && heightInRange;
}

bool isRealTimePeak(int32_t currentValue) {
  // Verifica si el valor actual es un pico en tiempo real
  return emgBuffer[1] >emgBuffer[0] && emgBuffer[1] > emgBuffer[2];
}

int32_t computeMean(int32_t* values, int size) {
  // Calcular la media de los valores
  int64_t sum = 0;
  for (int i = 0; i < size; i++) {
    sum += values[i];
  }
  return sum / (float)size;
}
int32_t computeStdDev(int32_t* values, int size, float mean) {
  // Calcular la desviación estándar de los valores
  int32_t sumSq = 0;
  for (int i = 0; i < size; i++) {
    sumSq += pow(values[i] - mean, 2);
  }
  return sqrt(sumSq / size);
}

void setup() {
  // Configuración inicial
  ads1292_init(); // Inicializa comunicación SPI y pines

 while (!configuracion) {
    Serial.print("Entrado en configuración...");
    emg_configuration();          // Inicializa el ADS1291
    leer_registros_config(); 
    if (!configuracion) {
      Serial.println("He entrado en delay");
      delay(8);  // Espera antes de volver a intentar
    }
  }
  // Solo si la configuración fue exitosa
  Serial.println("Configuración lista. Comenzando adquisición.");
  for (int i = 0; i < PEAK_WINDOW; i++) {
    emgBuffer[i] = 0;
  }
  enable_continuous_reading();
  delay(10);
  start_conversion(); // Inicia la conversión
  delay(10);
  attachInterrupt(ADS1292_DRDY_PIN, wait_data_DRDY, FALLING);
}

  /* void loop(){
  if (data_preparada) {
    data_preparada = false;
    readADS1292Samples();
    //double voltage = (emgData/ 8388608.0f) * ADS1292_SCALE; // Convertir a voltaje
    //Serial.println(filter1(voltage),20);
    auto raw = emgData;
    Serial.println(filter2(filter1(raw)));
    
}     
 */
   void loop() {
    // Bucle principal
    /* if (!calibrationStarted) {
      calibrationStartTime = millis();
      calibrationStarted = true;
    }  */
    if (data_preparada) {
      data_preparada = false;
      readADS1292Samples();
      int32_t emgValue = emgData; // Usar el valor EMG directamente
      //float voltage = ((float)emgValue / 8388607.0f) * 2.42f* 1000.0f / 12.0f; // Convertir a voltaje
      if (timer){
       //auto raw = emgData;
       //int32_t emgValue = filter2(filter1(raw)); // Es el filtro de 50 Hz
       int32_t filtered=(filter(emgValue)); // Imprimir el valor filtrado
       //Serial.println(filtered);
      //}}
         // Mover buffer para detección de pico
      emgBuffer[0] = emgBuffer[1];
      emgBuffer[1] = emgBuffer[2];
      emgBuffer[2] = filtered;
      if (bufferFillCount < 3) {
        bufferFillCount++;
        return;
      }

      if (millis() - calibrationStartTime < 10000) {
        return;
      }
      // Recolectar picos iniciales para calibración de rango
      if (!peakRangeComputed) {
        if (isRealTimePeak(emgBuffer[1]) && initialPeakCount < PEAK_SAMPLE_SIZE) {
          initialPeaks[initialPeakCount++] = emgBuffer[1];
          Serial.print("Recolectando pico inicial: ");
          Serial.println(emgBuffer[1]);
        }
        if (initialPeakCount >= PEAK_SAMPLE_SIZE) {
          // 1. Calcular mediana
          std::vector<int32_t> sortedPeaks(initialPeaks, initialPeaks + PEAK_SAMPLE_SIZE);
          std::sort(sortedPeaks.begin(), sortedPeaks.end());

          int32_t median;
          if (PEAK_SAMPLE_SIZE % 2 == 0) {
            median = (sortedPeaks[PEAK_SAMPLE_SIZE / 2 - 1] + sortedPeaks[PEAK_SAMPLE_SIZE / 2]) / 2;
          } else {
            median = sortedPeaks[PEAK_SAMPLE_SIZE / 2];
          }
          // 2. Calcular Desviación Absoluta Mediana (MAD)
          std::vector<int32_t> absDiffs;
          for (int i = 0; i < PEAK_SAMPLE_SIZE; i++) {
            absDiffs.push_back(abs(initialPeaks[i] - median));
          }
          std::sort(absDiffs.begin(), absDiffs.end());
          float mad;
          int mid = absDiffs.size() / 2;
          if (absDiffs.size() % 2 == 0) {
            mad = (absDiffs[mid - 1] + absDiffs[mid]) / 2.0;
          } else {
            mad = absDiffs[mid];
          }
          Serial.print("📉 Desviación Absoluta Mediana (MAD): ");
          Serial.println(mad);
          Serial.print("📊 Mediana: ");
          Serial.println(median);
          PEAK_MIN_HEIGHT = (median)-10*mad;
          PEAK_MAX_HEIGHT = (median)+10*mad;
          peakRangeComputed = true;
          Serial.println("✅ Rango de picos ajustado con terciles:");
          Serial.print("PEAK_MIN_HEIGHT = ");
          Serial.println(PEAK_MIN_HEIGHT);
          Serial.print("PEAK_MAX_HEIGHT = ");
          Serial.println(PEAK_MAX_HEIGHT);
        }

        return;
      }
      // Durante calibración
      if (!calibrationDone) {
        if (isCalibrationPeak(emgBuffer[1]) && peakCount < SAMPLE_SIZE) {
          peakValues[peakCount++] = emgBuffer[1];
          Serial.print("Pico detectado: ");
          Serial.println(emgBuffer[1]);
        }

        if (peakCount >= SAMPLE_SIZE) {
          int32_t meanPeak = computeMean(peakValues, peakCount);
          peakStdDev = computeStdDev(peakValues, peakCount, meanPeak);
          threshold = meanPeak +8* peakStdDev;

          calibrationDone = true;

          Serial.println("Calibración completa");
          Serial.print(" Media de picos: ");
          Serial.println(meanPeak);
          Serial.print(" Desviación estándar: ");
          Serial.println(peakStdDev);
          Serial.print("Umbral (media + 8σ): ");
          Serial.println(threshold);

          lastPeakValue = 0;
          lowPeakCount = 0;
        }
        return;
      }
// Detección de actividad muscular
if (isRealTimePeak(emgBuffer[1])) {
  int32_t currentPeak = emgBuffer[1];

  if (currentPeak > threshold) {
    lowPeakCount++;
    Serial.print("Pico bajo detectado (");
    Serial.print(lowPeakCount);
    Serial.println("/2)");

    if (lowPeakCount >= 1) {
      Serial.println("🟢 Músculo ON detectado");
      lowPeakCount = 0;
    }
  } else {
    if (lowPeakCount > 0) {
      Serial.println("⚠️ Pico no válido, reiniciando contador");
    }
    lowPeakCount = 0;
  }
}
    }
    }         
  }